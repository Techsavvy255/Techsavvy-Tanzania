/* Techsavvy Tanzania — course catalogue (the one place to edit course details)

   HOW TO ADD REAL LESSONS
   Replace  lessons: []  for a course with a list like this:
     lessons: [
       { title: "Welcome and set-up", url: "https://www.youtube.com/watch?v=..." },
       { title: "Lesson 1: the basics", url: "https://..." },
     ],
   Enrolled members then see these lessons when they press "Continue".

   IMPORTANT: anyone who views this page's source can read these links, so only use links that are
   fine to be public (for example an unlisted YouTube playlist or a public document).
*/
const COURSES = {
  "ai-chatgpt": {
    title: "Artificial Intelligence & ChatGPT",
    summary: "Understand how AI and tools like ChatGPT work, and how to use them responsibly to solve real problems.",
    outcomes: ["How AI and large language models work", "Practical prompting and AI-assisted workflows", "Ethical and responsible use of AI"],
    lessons: [],
  },
  "web-development": {
    title: "Web Development",
    summary: "Learn to design and build websites and web applications from the ground up.",
    outcomes: ["HTML, CSS, and JavaScript fundamentals", "Building responsive, real websites", "Introduction to front-end and back-end concepts"],
    lessons: [],
  },
  "graphic-design": {
    title: "Graphic Design",
    summary: "Develop the skills to create strong visual identities and digital designs.",
    outcomes: ["Design principles and visual composition", "Working with modern design tools", "Building a personal design portfolio"],
    lessons: [],
  },
  "networking": {
    title: "Networking",
    summary: "Understand how computer networks are built, configured, and maintained.",
    outcomes: ["Networking fundamentals and protocols", "Setting up and troubleshooting networks", "Introduction to network security basics"],
    lessons: [],
  },
  "cybersecurity": {
    title: "Cybersecurity",
    summary: "Learn to identify, prevent, and respond to digital security threats.",
    outcomes: ["Common threats and attack methods", "Practical security best practices", "Fundamentals of protecting systems and data"],
    lessons: [],
  },
  "digital-marketing": {
    title: "Digital Marketing",
    summary: "Learn how to grow an audience and market effectively in digital spaces.",
    outcomes: ["Social media and content strategy", "Understanding audiences and analytics", "Building a simple marketing plan"],
    lessons: [],
  },
  "content-creation": {
    title: "Content Creation",
    summary: "Build skills in storytelling through video, writing, and digital media.",
    outcomes: ["Planning and producing content", "Basic editing and production tools", "Building a consistent content style"],
    lessons: [],
  },
  "programming": {
    title: "Programming Fundamentals",
    summary: "Learn the logic and foundations behind writing code.",
    outcomes: ["Core programming concepts and logic", "Problem-solving through code", "A foundation for further specialization"],
    lessons: [],
  },
  "computer-fundamentals": {
    title: "Computer Fundamentals",
    summary: "Build essential computer literacy for those just starting out.",
    outcomes: ["Using a computer confidently and safely", "Core software and internet skills", "A foundation for any tech career path"],
    lessons: [],
  },
};
